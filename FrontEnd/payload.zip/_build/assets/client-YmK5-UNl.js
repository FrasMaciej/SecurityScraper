import{c as f}from"./client-DVwywZYZ.js";export{f as default};
