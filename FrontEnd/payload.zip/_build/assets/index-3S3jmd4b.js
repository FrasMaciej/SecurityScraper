import{j as o}from"./client-DVwywZYZ.js";const e=function(){return o.jsx("div",{children:'Hello "/"!'})};export{e as component};
